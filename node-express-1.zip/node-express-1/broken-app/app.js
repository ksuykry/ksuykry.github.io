const express = require('express');
let axios = require('axios');
var app = express();
//pushing an object of each developer into an array that has their bio and name
//use a list of developer names that we ALREADY HAVE
app.post('/', async function(req, res, next) {
  try {
    let devArr = [];
    const gitDevList = req.body.developers;
    for(let devName of gitDevList){
    const currentDev = await axios(`https://api.github.com/users/${devName}`
    devArr.push({name: currentDev.data.name, bio: currentDev.data.bio}))
    }


    return res.send(JSON.stringify(devArr));
  } catch {
    return next(err);
  }
});

app.listen(3000);
