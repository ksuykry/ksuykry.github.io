const fsP = require("fs/promises");



async function webReader(url) {
  try {
    return (await axios({ url })).data;
  } catch (err) {
    console.error(`Error fetching ${url}: ${err}`);
    process.exit(1);
  }
}
async function writeOutput(text, path) {
  try {
    let promises = [];
    let contents = await fsp.readFile("./urls.txt").split('\n');
    for(let i = 0; i < contents.length; i++){
      let web = webReader(contents[i]);
      await fsP.writeFile(`/${contents[i]}`, web , "utf8");
    }
  } catch (err) {
    console.error(`Couldn't write ${outPathOrUndef}: ${err}`);
    process.exit(1);
  }
}
