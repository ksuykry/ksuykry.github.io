### Conceptual Exercise

Answer the following questions below:

- What are some ways of managing asynchronous code in JavaScript?
  You can manage asynchronous code by using promises and await.  This makes the code run while a promise is pending and then await the resolved(fulfilled or rejected) state for the promise.

- What is a promise?
  A promise is an object with 3 states: pending, fulfilled and rejected.  When a promise is created, it's status is pending while we await the return of a response.  It changes to fulfilled or rejected depending on whether it was able to respond with a result.  They can only be used within an asynchronous function.

- What are the differences between an async function and a regular function?
  By declaring a function with async in front of it, we ensure that it can properly return the value of a fulfilled promise(or catching an error if it was rejected).

- What is the difference between Node.js and Express.js?

- What is the error-first callback pattern?
  The error-first callback pattern is when you call an error callback as an argument in another function to return and error if one is raised.  It is specifically used for asynchronous methods in APIs since we can't use try and catch for those.

- What is *middleware*?
  Middleware functions give us access to request and response objects.  We use it to find the data from our request that was sent to the server.  Examples of this include req.body to grab the data in the body of the request or using specifics like req.query.

- What does the `next` function do?
  Next is usually passed as an argument to a router function that tells it to call on the next matching middleware function following it.  It can be used to display an error and move to the next routing function.

- What does `RETURNING` do in SQL? When would you use it?
  Returning returns data that was inserted, updated, or deleted in a query.  You use it when you want to see exactly what was changed in the database without having to use another select query.

- Improve this function. Consider all aspects: performance, structure, naming).w

```js
async function getUsers() {
  let elie = await axios.get("https://api.github.com/users/elie");
  let joel = await axios.get("https://api.github.com/users/joelburton");
  let matt = await axios.get("https://api.github.com/users/mmmaaatttttt");

  return [elie, matt, joel];
}
```
